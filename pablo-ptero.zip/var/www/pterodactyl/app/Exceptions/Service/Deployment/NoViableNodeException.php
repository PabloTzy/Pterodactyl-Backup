<?php

namespace Pterodactyl\Exceptions\Service\Deployment;

use Pterodactyl\Exceptions\DisplayException;

class NoViableNodeException extends DisplayException
{
}
