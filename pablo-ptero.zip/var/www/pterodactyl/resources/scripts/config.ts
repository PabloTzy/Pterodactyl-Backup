export default {
    TERMINAL_PRELUDE: 'container@PabloNetwork~ ',
};
